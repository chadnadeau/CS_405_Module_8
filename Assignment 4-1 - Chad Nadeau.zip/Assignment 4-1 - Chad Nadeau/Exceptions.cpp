#include <iostream>
#include <stdexcept>
#include <string>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
private:
    std::string message;

public:
    explicit CustomException(const std::string& msg) : message(msg) {}
    const char* what() const noexcept override {
        return message.c_str();
    }
};

bool do_even_more_custom_application_logic() {
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // Throwing a standard exception (std::runtime_error)
    throw std::runtime_error("An error occurred in do_even_more_custom_application_logic.");

    return true; // This line won't be reached because of the exception
}

void do_custom_application_logic() {
    try {
        std::cout << "Running Custom Application Logic." << std::endl;

        // Wrapping the call to do_even_more_custom_application_logic in a try-catch block
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex) {
        // Catching standard exceptions and displaying the message
        std::cerr << "Standard exception caught: " << ex.what() << std::endl;
    }

    // Throwing a custom exception
    throw CustomException("A custom exception occurred in do_custom_application_logic.");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den) {
    if (den == 0) {
        // Throwing a standard exception for divide by zero
        throw std::invalid_argument("Division by zero is not allowed.");
    }
    return num / den;
}

void do_division() noexcept {
    try {
        float numerator = 10.0f;
        float denominator = 0.0f;

        // Calling divide, which might throw an exception
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& ex) {
        // Catching only divide-by-zero exceptions
        std::cerr << "Exception in do_division: " << ex.what() << std::endl;
    }
}

int main() {
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // Perform division
        do_division();

        // Perform custom application logic
        do_custom_application_logic();

    }
    catch (const CustomException& ex) {
        // Catching custom exceptions
        std::cerr << "CustomException caught in main: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex) {
        // Catching standard exceptions
        std::cerr << "Standard exception caught in main: " << ex.what() << std::endl;
    }
    catch (...) {
        // Catching any uncaught exceptions
        std::cerr << "An unknown exception was caught in main." << std::endl;
    }

    std::cout << "Program completed successfully." << std::endl;
    return 0;
}
